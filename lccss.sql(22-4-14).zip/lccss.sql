-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 22, 2014 at 07:09 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lccss`
--

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE IF NOT EXISTS `alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `sender_signature` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `alerts`
--


-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `points` varchar(255) DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(255) DEFAULT NULL,
  `address` text,
  `created_at` date DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `name`, `points`, `owner_name`, `mobile_number`, `address`, `created_at`, `email_id`) VALUES
(1, 'Default', '500000', 'Xavoc Technocrats', '+91 8875191258', '18/436 Gayatri Marg, Kanji Ka Hata, Dhabai Ji Ka Wada, udaipur', '2011-12-12', 'info@xavoc.com');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_company`
--

CREATE TABLE IF NOT EXISTS `customercareapp_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `epan_id` int(11) DEFAULT NULL,
  `config_id` int(11) DEFAULT NULL,
  `company_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`),
  KEY `fk_config_id` (`config_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `customercareapp_company`
--

INSERT INTO `customercareapp_company` (`id`, `name`, `epan_id`, `config_id`, `company_address`) VALUES
(1, 'CG Kriti', 1, NULL, NULL),
(2, 'comp1', NULL, NULL, NULL),
(3, 'comp2', NULL, NULL, NULL),
(4, 'comp3', NULL, NULL, NULL),
(5, 'comp4', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_config`
--

CREATE TABLE IF NOT EXISTS `customercareapp_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `helpDeskName` varchar(255) DEFAULT NULL,
  `helpDeskUrl` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `company_email` varchar(255) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `owner_email` varchar(255) DEFAULT NULL,
  `owner_phone_no` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `updated` varchar(255) DEFAULT NULL,
  `logo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_logo_id` (`logo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `customercareapp_config`
--

INSERT INTO `customercareapp_config` (`id`, `helpDeskName`, `helpDeskUrl`, `company_name`, `company_email`, `phone_no`, `owner_name`, `owner_email`, `owner_phone_no`, `address`, `logo`, `updated`, `logo_id`) VALUES
(1, 'Xepan Support', '/suport', 'Xavoc Technocrates Pvt. Ltd.', 'info@xavoc.com', '1234567890', 'Mr. Gowrav Vishwakarma', 'gowravvishwakarma@gmail.com', '1234567890', '17, sai darshan appartment', 'xEpan', '2014-04-10 0808:0404:0303', 2);

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_customer`
--

CREATE TABLE IF NOT EXISTS `customercareapp_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customercareapp_customer`
--

INSERT INTO `customercareapp_customer` (`id`, `name`, `phone_number`, `email`, `address`, `password`) VALUES
(1, 'khushbu', '1234567890', 'khushbu@xavoc.com', 'udaipur', '123'),
(2, 'priti', '1234567890', 'priti@xavoc.com', '', '123');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_department`
--

CREATE TABLE IF NOT EXISTS `customercareapp_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `customercareapp_department`
--

INSERT INTO `customercareapp_department` (`id`, `name`, `description`) VALUES
(1, 'dept1', NULL),
(2, 'dept1', NULL),
(3, 'dept2', NULL),
(4, 'dept3', NULL),
(5, 'dept4', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_emailtemplate`
--

CREATE TABLE IF NOT EXISTS `customercareapp_emailtemplate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `msgbody` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `customercareapp_emailtemplate`
--

INSERT INTO `customercareapp_emailtemplate` (`id`, `name`, `subject`, `msgbody`) VALUES
(1, 'Send Ticket ID', 'Recived your ', 'Dear Customer,\r\n\r\nYour complaint is registered to xEpan Support. Your complaint id is : <?ticket_id?>ticket_id<?/ticket_id?>\r\nWe will get back to you soon.\r\n\r\n'),
(2, 'temp1', NULL, NULL),
(3, 'temp2', NULL, NULL),
(4, 'temp3', NULL, NULL),
(5, 'temp4', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_issue`
--

CREATE TABLE IF NOT EXISTS `customercareapp_issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerCareApp_company_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customerCareApp_company_id` (`customerCareApp_company_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `customercareapp_issue`
--

INSERT INTO `customercareapp_issue` (`id`, `customerCareApp_company_id`, `name`) VALUES
(1, 1, 'ISSUE');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_project`
--

CREATE TABLE IF NOT EXISTS `customercareapp_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `created_at` date DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customer_id` (`customer_id`),
  KEY `fk_staff_id` (`staff_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `customercareapp_project`
--

INSERT INTO `customercareapp_project` (`id`, `customer_id`, `staff_id`, `name`, `description`, `created_at`, `price`, `is_active`, `status`) VALUES
(1, 1, 1, 'test', '', '2014-04-10', 0.00, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_staff`
--

CREATE TABLE IF NOT EXISTS `customercareapp_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `employee_code` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_department_id` (`department_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customercareapp_staff`
--

INSERT INTO `customercareapp_staff` (`id`, `name`, `department_id`, `employee_code`, `designation`, `phone_number`, `email`, `address`, `gender`, `dob`, `doj`, `password`) VALUES
(1, 'staff1', 1, '', '', '8875191258', 'kriti.xavoc@hotmail.com', 'kjlkj', '', '1970-01-01', '1970-01-01', '123'),
(2, 'staff2', NULL, '', '', '', '', '', NULL, NULL, NULL, '123');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_team`
--

CREATE TABLE IF NOT EXISTS `customercareapp_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_department_id` (`department_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `customercareapp_team`
--

INSERT INTO `customercareapp_team` (`id`, `name`, `department_id`) VALUES
(1, 'TEAM1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_ticket`
--

CREATE TABLE IF NOT EXISTS `customercareapp_ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) DEFAULT NULL,
  `detail` text,
  `customer_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `tickettype_id` int(11) DEFAULT NULL,
  `ticketpriority_id` int(11) DEFAULT NULL,
  `ticketstatus_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customer_id` (`customer_id`),
  KEY `fk_staff_id` (`staff_id`),
  KEY `fk_tickettype_id` (`tickettype_id`),
  KEY `fk_ticketpriority_id` (`ticketpriority_id`),
  KEY `fk_ticketstatus_id` (`ticketstatus_id`),
  KEY `fk_project_id` (`project_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customercareapp_ticket`
--

INSERT INTO `customercareapp_ticket` (`id`, `subject`, `detail`, `customer_id`, `staff_id`, `tickettype_id`, `ticketpriority_id`, `ticketstatus_id`, `project_id`) VALUES
(2, 'kdlkfsj', 'jkjh\r\n', 1, 1, 1, 2, 3, NULL),
(3, 'fggdf', 'dghdg', 1, 1, 2, 2, 3, NULL),
(4, 'dmsm', 'lkmdsfl', 2, 1, 3, 3, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_ticketpriority`
--

CREATE TABLE IF NOT EXISTS `customercareapp_ticketpriority` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customercareapp_ticketpriority`
--

INSERT INTO `customercareapp_ticketpriority` (`id`, `name`, `color`) VALUES
(1, 'low', '#DDFFDD'),
(2, 'normal', '#FFFFF0'),
(3, 'high', '#FEE7E7'),
(4, 'emergency', '#FEE7E7');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_ticketstatus`
--

CREATE TABLE IF NOT EXISTS `customercareapp_ticketstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customercareapp_ticketstatus`
--

INSERT INTO `customercareapp_ticketstatus` (`id`, `name`) VALUES
(1, 'Normal'),
(2, 'High'),
(3, 'Low'),
(4, 'Emergency');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_tickettype`
--

CREATE TABLE IF NOT EXISTS `customercareapp_tickettype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customercareapp_tickettype`
--

INSERT INTO `customercareapp_tickettype` (`id`, `name`) VALUES
(1, 'System'),
(2, 'Website'),
(3, 'Software'),
(4, 'Hardware');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_ticket_status`
--

CREATE TABLE IF NOT EXISTS `customercareapp_ticket_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customercareapp_ticket_status`
--

INSERT INTO `customercareapp_ticket_status` (`id`, `name`) VALUES
(1, 'open'),
(2, 'close');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_user`
--

CREATE TABLE IF NOT EXISTS `customercareapp_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerCareApp_company_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customerCareApp_company_id` (`customerCareApp_company_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `customercareapp_user`
--

INSERT INTO `customercareapp_user` (`id`, `customerCareApp_company_id`, `name`) VALUES
(1, 1, 'khushi');

-- --------------------------------------------------------

--
-- Table structure for table `epan`
--

CREATE TABLE IF NOT EXISTS `epan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `fund_alloted` varchar(255) DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `contact_person_name` varchar(255) DEFAULT NULL,
  `mobile_no` varchar(255) DEFAULT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `website` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT NULL,
  `last_email_sent` datetime DEFAULT NULL,
  `allowed_aliases` int(11) DEFAULT NULL,
  `parked_domain` varchar(255) DEFAULT NULL,
  `email_host` varchar(255) DEFAULT NULL,
  `email_port` varchar(255) DEFAULT NULL,
  `email_username` varchar(255) DEFAULT NULL,
  `email_password` varchar(255) DEFAULT NULL,
  `email_reply_to` varchar(255) DEFAULT NULL,
  `email_reply_to_name` varchar(255) DEFAULT NULL,
  `email_from` varchar(255) DEFAULT NULL,
  `email_from_name` varchar(255) DEFAULT NULL,
  `is_frontent_regiatrstion_allowed` tinyint(1) DEFAULT NULL,
  `user_activation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_staff1` (`staff_id`),
  KEY `fk_epan_epan_categories1` (`category_id`),
  FULLTEXT KEY `tags_description_full_text` (`keywords`,`description`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `epan`
--

INSERT INTO `epan` (`id`, `name`, `staff_id`, `branch_id`, `password`, `fund_alloted`, `created_at`, `category_id`, `company_name`, `contact_person_name`, `mobile_no`, `address`, `city`, `state`, `country`, `email_id`, `keywords`, `description`, `website`, `is_active`, `is_approved`, `last_email_sent`, `allowed_aliases`, `parked_domain`, `email_host`, `email_port`, `email_username`, `email_password`, `email_reply_to`, `email_reply_to_name`, `email_from`, `email_from_name`, `is_frontent_regiatrstion_allowed`, `user_activation`) VALUES
(1, 'web', 1, 1, 'admin', '5000000', '2014-01-26', 1, 'Xavoc Technocrats Pvt. Ltd.', 'Xavoc Admin', '+91 8875191258', '18/436, Gayatri marg, Kanji Ka hata, Udaipur, Rajasthan , India', 'Udaipur', 'Rajasthan', 'India', 'info@xavoc.com', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', 'World''s best and easiest cms :)', 'http://www.xavoc.com', 1, 1, NULL, 1, NULL, '', '', '', '', '', '', '', '', 1, 'self_activated'),
(2, 'web2', 1, 1, 'admin2', '5000000', '2014-03-25', 1, 'Cg Kriti', 'Kriti Joshi', '1234567890', 'udaipur', 'udaipur', 'rajasthan', 'india', 'kriti.xavoc@hotmai.com', NULL, NULL, NULL, 1, 1, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'self_activated');

-- --------------------------------------------------------

--
-- Table structure for table `epan_aliases`
--

CREATE TABLE IF NOT EXISTS `epan_aliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `epan_aliases`
--


-- --------------------------------------------------------

--
-- Table structure for table `epan_categories`
--

CREATE TABLE IF NOT EXISTS `epan_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `parent_category_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cat_id` (`id`),
  KEY `cat_parent` (`parent_category_id`),
  KEY `func_getPathWay` (`id`,`parent_category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `epan_categories`
--

INSERT INTO `epan_categories` (`id`, `name`, `description`, `parent_category_id`, `ordering`) VALUES
(1, 'Default', 'Default', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `epan_components_marketplace`
--

CREATE TABLE IF NOT EXISTS `epan_components_marketplace` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `is_final` tinyint(1) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `allowed_children` varchar(255) DEFAULT NULL,
  `specific_to` varchar(255) DEFAULT NULL,
  `namespace` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `is_system` tinyint(1) DEFAULT NULL,
  `plugin_hooked` text,
  `description` text,
  `default_enabled` tinyint(1) DEFAULT NULL,
  `has_toolbar_tools` tinyint(1) DEFAULT NULL,
  `has_owner_modules` tinyint(1) DEFAULT NULL,
  `has_plugins` tinyint(1) DEFAULT NULL,
  `has_live_edit_app_page` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `epan_components_marketplace`
--

INSERT INTO `epan_components_marketplace` (`id`, `name`, `is_final`, `rate`, `allowed_children`, `specific_to`, `namespace`, `type`, `is_system`, `plugin_hooked`, `description`, `default_enabled`, `has_toolbar_tools`, `has_owner_modules`, `has_plugins`, `has_live_edit_app_page`) VALUES
(1, 'Image', 1, '50', NULL, NULL, 'imageElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(2, 'RowColumn', 0, '0', '3', '', 'rowColumnElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(4, 'SlideShow', 0, '0', '5', '', 'slideshowModule', 'module', 0, NULL, NULL, NULL, 1, NULL, 0, NULL),
(6, 'Text', 0, '0', NULL, NULL, 'textElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(7, 'Title', 1, '0', NULL, NULL, 'titleElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(8, 'EnquiryForm', 1, '0', '', NULL, 'enquiryformModule', 'module', 0, NULL, NULL, NULL, 1, NULL, 0, NULL),
(10, 'MenuBar', 0, '0', '11', '', 'menubarModule', 'module', 0, NULL, NULL, NULL, 1, NULL, 0, NULL),
(13, 'SystemContentManipulations', 1, '0', NULL, NULL, 'systemcontentmanipulationPlugins', 'plugins', 1, 'output-fetched', NULL, 1, NULL, NULL, 1, NULL),
(12, 'Container', 0, '0', '', '', 'containerElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(16, 'SocialShare', NULL, NULL, NULL, NULL, 'socialshareModule', 'module', 0, NULL, NULL, NULL, 1, NULL, 0, NULL),
(20, 'Backup And Restore App', NULL, NULL, NULL, NULL, 'backupandrestoreApp', 'application', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'Simple Image Gallary App', NULL, NULL, NULL, NULL, 'simpleImageGallaryApp', 'application', 0, NULL, 'bla bla bla', 0, 1, 0, 0, 0),
(22, 'Visitor Counter', NULL, NULL, NULL, NULL, 'visitorCounterApp', 'application', 0, 'epan-hit', 'sdfsd', 0, 1, 0, 0, 0),
(26, 'User Login', NULL, NULL, NULL, NULL, 'userLoginElement', 'element', 1, NULL, NULL, 0, 1, NULL, NULL, NULL),
(28, 'customerCareApp', 0, '0', NULL, NULL, 'customerCareApp', 'application', 0, NULL, 'A Complete Customer care system with tickets and live support', NULL, 1, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `epan_installed_components`
--

CREATE TABLE IF NOT EXISTS `epan_installed_components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `component_id` int(11) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `params` varchar(255) DEFAULT NULL,
  `installed_on` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `epan_installed_components`
--

INSERT INTO `epan_installed_components` (`id`, `epan_id`, `component_id`, `enabled`, `params`, `installed_on`) VALUES
(1, 1, 13, 1, NULL, '2014-01-26'),
(2, 1, 8, 1, NULL, '2014-01-27'),
(5, 1, 27, 1, NULL, '2014-02-06'),
(6, 1, 10, 1, NULL, '2014-02-08'),
(9, 1, 4, 1, NULL, '2014-02-09'),
(11, 1, 21, 1, NULL, '2014-02-09'),
(12, 1, 22, 1, NULL, '2014-02-09'),
(13, 1, 28, 1, NULL, '2014-02-15');

-- --------------------------------------------------------

--
-- Table structure for table `epan_page`
--

CREATE TABLE IF NOT EXISTS `epan_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `menu_caption` varchar(255) DEFAULT NULL,
  `epan_id` int(11) DEFAULT NULL,
  `is_template` tinyint(1) DEFAULT NULL,
  `title` text,
  `description` text,
  `keywords` text,
  `content` text,
  `body_attributes` text,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `access_level` varchar(255) DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_page_epan1` (`epan_id`),
  KEY `fk_template_id` (`template_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `epan_page`
--

INSERT INTO `epan_page` (`id`, `name`, `menu_caption`, `epan_id`, `is_template`, `title`, `description`, `keywords`, `content`, `body_attributes`, `created_on`, `updated_on`, `access_level`, `template_id`) VALUES
(1, 'home', 'Home', 1, 0, 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', '\n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n  \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n<div id="bbc1eb20-59d3-4b14-e7bd-b0eeae1b6ec5" data-responsible-namespace="customerCareApp" data-responsible-view="View_Server_StaffLogin" data-is-serverside-component="true" component_namespace="customerCareApp" component_type="StaffLogin" class=" epan-component " style=""><div id="36d6456c__erver_stafflogin" class="" style="">\n\n<div id="36d6456c__erver_stafflogin_form" class="atk-form  atk4_form_widget" style="">\n  \n  <form class="atk4_form" id="36d6456c__erver_stafflogin_form_form" name="36d6456c__erver_stafflogin_form_form" action="/kriti/xepan/?epan=web&amp;subpage=home&amp;submit=36d6456c__erver_stafflogin_form" method="POST">\n    <fieldset class="">\n<div class="atk-form-row atk-row atk-form-row-line ">\n        <label for="36d6456c__erver_stafflogin_form_email"><span>Email</span></label>\n        <div class="atk-form-field "><input data-initvalue="admin" name="36d6456c__erver_stafflogin_form_email" data-shortname="email" id="36d6456c__erver_stafflogin_form_email" value="" type="text"></div>\n        \n        \n      </div>\n      \n      <div class="atk-form-row atk-row atk-form-row-password ">\n        <label for="36d6456c__erver_stafflogin_form_password"><span>Password</span></label>\n        <div class="atk-form-field "><input data-initvalue="admin" name="36d6456c__erver_stafflogin_form_password" data-shortname="password" id="36d6456c__erver_stafflogin_form_password" value="" type="password"></div>\n        \n        \n      </div>\n      \n      \n    </fieldset>\n<div class="atk-buttons ">\n      \n<button data-initvalue="" aria-disabled="false" role="button" id="36d6456c__erver_stafflogin_form_form_submit" style="" type="submit" class="ui-state-default ui-corner-all  ui-button ui-widget ui-button-text-only" name="36d6456c__erver_stafflogin_form_form_submit"><span class="ui-button-text">Login</span></button>\n\n    </div>\n    \n  <input data-initvalue="1" name="ajax_submit" id="ajax_submit" value="1" type="hidden"></form>\n</div>\n</div>\n</div>\n\n\n\n', 'cursor: auto;', NULL, '2014-04-10 12:30:57', 'public', 1),
(6, 'xcustomercare-staffticket', '', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', '\n  \n  \n<div id="bf684047-34f6-425e-ea3d-f3a1621f641e" data-responsible-namespace="customerCareApp" data-responsible-view="View_Server_TicketManagement" data-is-serverside-component="true" component_namespace="customerCareApp" component_type="TicketManagement" class=" epan-component " style=""><div id="36d6456c__erver_ticketmanagement" class="" style="">\n<button aria-disabled="false" role="button" id="36d6456c__erver_ticketmanagement_button" style="" type="button" class="ui-state-default ui-corner-all  ui-button ui-widget ui-button-text-only" name="36d6456c__erver_ticketmanagement_button"><span class="ui-button-text">Add</span></button>\n\n<div id="36d6456c__erver_ticketmanagement_grid" class="atk-grid  ticketclass atk4_grid" style="">\n  \n  \n  <div class="atk-grid-panel clearfix"></div>\n  \n  \n  \n  <table width="100%">\n\n    \n    <thead class="ui-widget-header"><tr>\n      \n        <th id="" class="ui-widget-header">Customer</th>\n        \n        <th id="" class="ui-widget-header">Staff</th>\n        \n        <th id="" class="ui-widget-header">Tickettype</th>\n        \n        <th id="" class="ui-widget-header">Ticketpriority</th>\n        \n        <th id="" class="ui-widget-header">Ticketstatus</th>\n        \n        <th id="" class="ui-widget-header">Subject</th>\n        \n        <th id="" class="ui-widget-header">Detail</th>\n        \n        <th id="" class="ui-widget-header" style="width: 40px; text-align: center">Edit</th>\n        \n        <th id="" class="ui-widget-header" style="width: 40px; text-align: center">Delete</th>\n        \n    </tr></thead>\n    \n    \n\n    <tbody class="grid_body">\n      \n      <tr class="odd" data-id="2" rel="2">\n      \n        <td style="white-space:nowrap">khushbu</td>\n        \n        <td style="white-space:nowrap">staff1</td>\n        \n        <td style="white-space:nowrap">System</td>\n        \n        <td style="white-space:nowrap">normal</td>\n        \n        <td style="white-space:nowrap">Low</td>\n        \n        <td style="white-space:nowrap">kdlkfsj</td>\n        \n        <td title="jkjh\n">jkjh\n</td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_edit ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/kriti/xepan/?epan=web&amp;subpage=xcustomercare-staffticket&amp;edit=2&amp;36d6456c__erver_ticketmanagement_grid_edit=2'')"><span class="ui-button-text">Edit</span></button></td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_delete ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/kriti/xepan/?epan=web&amp;subpage=xcustomercare-staffticket&amp;delete=2&amp;36d6456c__erver_ticketmanagement_grid_delete=2'')"><span class="ui-button-text">Delete</span></button></td>\n        \n      </tr>\n      \n      <tr class="even" data-id="3" rel="3">\n      \n        <td style="white-space:nowrap">khushbu</td>\n        \n        <td style="white-space:nowrap">staff1</td>\n        \n        <td style="white-space:nowrap">Website</td>\n        \n        <td style="white-space:nowrap">normal</td>\n        \n        <td style="white-space:nowrap">Low</td>\n        \n        <td style="white-space:nowrap">fggdf</td>\n        \n        <td title="dghdg">dghdg</td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_edit ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/kriti/xepan/?epan=web&amp;subpage=xcustomercare-staffticket&amp;edit=3&amp;36d6456c__erver_ticketmanagement_grid_edit=3'')"><span class="ui-button-text">Edit</span></button></td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_delete ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/kriti/xepan/?epan=web&amp;subpage=xcustomercare-staffticket&amp;delete=3&amp;36d6456c__erver_ticketmanagement_grid_delete=3'')"><span class="ui-button-text">Delete</span></button></td>\n        \n      </tr>\n      \n    </tbody>\n\n    \n\n  </table>\n  \n  \n\n  \n  \n  \n</div>\n</div>\n</div>\n\n', 'cursor: auto; overflow: auto;', '2014-04-10 13:36:55', '2014-04-10 14:06:06', 'public', 3),
(3, 'xcustomercare-staffdashboard', '', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', NULL, NULL, '2014-04-10 13:00:01', '2014-04-10 13:00:01', 'public', 3),
(4, 'xcustomercare-stafflogin', '', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', NULL, NULL, '2014-04-10 13:15:15', '2014-04-10 13:15:16', 'public', 1),
(5, 'xcustomercare-staffprofile', '', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', '\n  \n<div id="151787ad-d1f1-4b4d-a878-1d524259ce0a" data-responsible-namespace="customerCareApp" data-responsible-view="View_Server_StaffProfile" data-is-serverside-component="true" component_namespace="customerCareApp" component_type="StaffProfile" class=" epan-component " style=""> 	<div style="background-color:black; color:white">This is server side component, save your page and reload to render it</div> </div>', 'cursor: auto;', '2014-04-10 13:27:42', '2014-04-10 13:33:03', 'public', 3),
(7, 'xcustomercare-staffproject', '', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', '\n  \n  \n  \n\n\n<div id="5f83c677-4bd2-414c-a6b4-249fe3057d14" data-responsible-namespace="customerCareApp" data-responsible-view="View_Server_ProjectManagement" data-is-serverside-component="true" component_namespace="customerCareApp" component_type="ProjectManagement" class=" epan-component " style=""><div id="36d6456c__erver_projectmanagement" class="" style="">\n<button aria-disabled="false" role="button" id="36d6456c__erver_projectmanagement_button" style="" type="button" class="ui-state-default ui-corner-all  ui-button ui-widget ui-button-text-only ui-state-focus" name="36d6456c__erver_projectmanagement_button"><span class="ui-button-text">Add</span></button>\n\n<div id="36d6456c__erver_projectmanagement_grid" class="atk-grid  projectclass atk4_grid" style="">\n  \n  \n  <div class="atk-grid-panel clearfix"></div>\n  \n  \n  \n  <table width="100%">\n<thead class="ui-widget-header"><tr>\n<th id="" class="ui-widget-header">Customer</th>\n        \n        <th id="" class="ui-widget-header">Staff</th>\n        \n        <th id="" class="ui-widget-header">Project Name</th>\n        \n        <th id="" class="ui-widget-header">Description</th>\n        \n        <th id="" class="ui-widget-header">Created At</th>\n        \n        <th id="" class="ui-widget-header" style="text-align: right">Price</th>\n        \n        <th id="" class="ui-widget-header" style="text-align: center">Is Active</th>\n        \n        <th id="" class="ui-widget-header">Status</th>\n        \n        <th id="" class="ui-widget-header" style="width: 40px; text-align: center">Edit</th>\n        \n        <th id="" class="ui-widget-header" style="width: 40px; text-align: center">Delete</th>\n        \n    </tr></thead>\n<tbody class="grid_body"><tr class="odd" data-id="1" rel="1">\n<td style="white-space:nowrap">khushbu</td>\n        \n        <td style="white-space:nowrap">staff1</td>\n        \n        <td style="white-space:nowrap">test</td>\n        \n        <td title=""></td>\n        \n        <td style="white-space:nowrap">10/04/2014</td>\n        \n        <td style="white-space:nowrap;" align="right">0.00</td>\n        \n        <td style="white-space:nowrap"><div align="center"><span class="ui-icon ui-icon-check">yes</span></div></td>\n        \n        <td style="white-space:nowrap"></td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_edit ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/kriti/xepan/?subpage=xcustomercare-staffproject&amp;edit=1&amp;36d6456c__erver_projectmanagement_grid_edit=1'')"><span class="ui-button-text">Edit</span></button></td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_delete ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/kriti/xepan/?subpage=xcustomercare-staffproject&amp;delete=1&amp;36d6456c__erver_projectmanagement_grid_delete=1'')"><span class="ui-button-text">Delete</span></button></td>\n        \n      </tr></tbody>\n</table>\n</div>\n</div>\n</div>\n\n', 'cursor: auto; overflow: auto;', '2014-04-10 14:06:43', '2014-04-10 14:39:31', 'public', 3),
(8, 'xcustomercare-customerlogin', 'Customer Login', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', '\n  \n  \n<div id="8cf50afe-dd89-4a2b-af43-9c88ccd04cc8" data-responsible-namespace="customerCareApp" data-responsible-view="View_Server_CustomerLogin" data-is-serverside-component="true" component_namespace="customerCareApp" component_type="CustomerLogin" class=" epan-component " style=""><div id="36d6456c__erver_customerlogin" class="" style="">\n<h1 id="36d6456c__erver_customerlogin_h1" class="" style="" align="center">Customer Login Panel</h1>\n\n\n<div id="36d6456c__erver_customerlogin_form" class="atk-form  atk4_form_widget" style="">\n  \n  <form class="atk4_form" id="36d6456c__erver_customerlogin_form_form" name="36d6456c__erver_customerlogin_form_form" action="/xepan/?epan=web&amp;subpage=xcustomercare-customerlogin&amp;submit=36d6456c__erver_customerlogin_form" method="POST">\n    <fieldset class="">\n<div class="atk-form-row atk-row atk-form-row-line ">\n        <label for="36d6456c__erver_customerlogin_form_email" class="mandatory"><span>Email</span></label>\n        <div class="atk-form-field "><input data-initvalue="" name="36d6456c__erver_customerlogin_form_email" data-shortname="email" id="36d6456c__erver_customerlogin_form_email" value="" type="text"></div>\n        \n        \n      </div>\n      \n      <div class="atk-form-row atk-row atk-form-row-password ">\n        <label for="36d6456c__erver_customerlogin_form_password" class="mandatory"><span>Password</span></label>\n        <div class="atk-form-field "><input data-initvalue="" name="36d6456c__erver_customerlogin_form_password" data-shortname="password" id="36d6456c__erver_customerlogin_form_password" value="" type="password"></div>\n        \n        \n      </div>\n      \n<button data-initvalue="" aria-disabled="false" role="button" id="36d6456c__erver_customerlogin_form_button" style=";margin-top:25px;margin-left:37px" type="button" class="ui-state-default ui-corner-all  ui-button ui-widget ui-button-text-only" name="36d6456c__erver_customerlogin_form_button"><span class="ui-button-text">Login</span></button>\n\n      \n    </fieldset>\n<div class="atk-buttons ">\n      \n    </div>\n    \n  <input data-initvalue="1" name="ajax_submit" id="ajax_submit" value="1" type="hidden"></form>\n</div>\n</div>\n</div>\n\n', 'cursor: auto;', '2014-04-22 18:13:38', '2014-04-22 18:33:01', 'public', 5),
(9, 'xcustomercare-customeropenticket', 'Open Ticket', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', '\n  \n  \n  \n  \n  \n\n\n\n<div id="7987ba99-3c7d-4dca-8fd5-3b27f4773cf3" data-responsible-namespace="customerCareApp" data-responsible-view="View_Server_CustomerOpenTicket" data-is-serverside-component="true" component_namespace="customerCareApp" component_type="CustomerOpenTicket" class=" epan-component " style=""><div id="36d6456c__erver_customeropenticket" class="" style="">\n<div id="36d6456c__erver_customeropenticket_view_info" style="" class="atk-notification ui-state-highlight ui-corner-all ">\n  <div class="atk-notification-text">\n    <i class="ui-icon ui-icon-info"></i>I Am Customer Open Ticket\n  </div>\n  \n</div>\n</div>\n</div>\n\n\n', 'cursor: auto;', '2014-04-22 18:23:18', '2014-04-22 18:43:33', 'public', 5),
(10, 'xcustomercare-customerticketstatus', '', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', '\n  \n  \n<div id="e476269d-8e59-41e6-a08c-b079f44db728" data-responsible-namespace="customerCareApp" data-responsible-view="View_Server_CustomerTicketStatus" data-is-serverside-component="true" component_namespace="customerCareApp" component_type="CustomerTicketStatus" class=" epan-component " style=""><div id="36d6456c__erver_customerticketstatus" class="" style="">\n<div id="36d6456c__erver_customerticketstatus_view_info" style="" class="atk-notification ui-state-highlight ui-corner-all ">\n  <div class="atk-notification-text">\n    <i class="ui-icon ui-icon-info"></i>I Am Customer Ticket Status\n  </div>\n  \n</div>\n\n<button aria-disabled="false" role="button" id="36d6456c__erver_customerticketstatus_button" style="" type="button" class="ui-state-default ui-corner-all  ui-button ui-widget ui-button-text-only" name="36d6456c__erver_customerticketstatus_button"><span class="ui-button-text">Add</span></button>\n\n<div id="36d6456c__erver_customerticketstatus_grid" class="atk-grid  ticketclass atk4_grid" style="">\n  \n  \n  <div class="atk-grid-panel clearfix"></div>\n  \n  \n  \n  <table width="100%">\n<thead class="ui-widget-header"><tr>\n<th id="" class="ui-widget-header">Customer</th>\n        \n        <th id="" class="ui-widget-header">Staff</th>\n        \n        <th id="" class="ui-widget-header">Project</th>\n        \n        <th id="" class="ui-widget-header">Tickettype</th>\n        \n        <th id="" class="ui-widget-header">Ticketpriority</th>\n        \n        <th id="" class="ui-widget-header">Ticketstatus</th>\n        \n        <th id="" class="ui-widget-header">Subject</th>\n        \n        <th id="" class="ui-widget-header">Detail</th>\n        \n        <th id="" class="ui-widget-header" style="width: 40px; text-align: center">Edit</th>\n        \n        <th id="" class="ui-widget-header" style="width: 40px; text-align: center">Delete</th>\n        \n    </tr></thead>\n<tbody class="grid_body">\n<tr class="odd" data-id="2" rel="2">\n<td style="white-space:nowrap">khushbu</td>\n        \n        <td style="white-space:nowrap">staff1</td>\n        \n        <td style="white-space:nowrap"></td>\n        \n        <td style="white-space:nowrap">System</td>\n        \n        <td style="white-space:nowrap">normal</td>\n        \n        <td style="white-space:nowrap">Low</td>\n        \n        <td style="white-space:nowrap">kdlkfsj</td>\n        \n        <td title="jkjh\n">jkjh\n</td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_edit ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/xepan/?subpage=xcustomercare-customerticketstatus&amp;edit=2&amp;36d6456c__erver_customerticketstatus_grid_edit=2'')"><span class="ui-button-text">Edit</span></button></td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_delete ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/xepan/?subpage=xcustomercare-customerticketstatus&amp;delete=2&amp;36d6456c__erver_customerticketstatus_grid_delete=2'')"><span class="ui-button-text">Delete</span></button></td>\n        \n      </tr>\n<tr class="even" data-id="3" rel="3">\n<td style="white-space:nowrap">khushbu</td>\n        \n        <td style="white-space:nowrap">staff1</td>\n        \n        <td style="white-space:nowrap"></td>\n        \n        <td style="white-space:nowrap">Website</td>\n        \n        <td style="white-space:nowrap">normal</td>\n        \n        <td style="white-space:nowrap">Low</td>\n        \n        <td style="white-space:nowrap">fggdf</td>\n        \n        <td title="dghdg">dghdg</td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_edit ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/xepan/?subpage=xcustomercare-customerticketstatus&amp;edit=3&amp;36d6456c__erver_customerticketstatus_grid_edit=3'')"><span class="ui-button-text">Edit</span></button></td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_delete ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/xepan/?subpage=xcustomercare-customerticketstatus&amp;delete=3&amp;36d6456c__erver_customerticketstatus_grid_delete=3'')"><span class="ui-button-text">Delete</span></button></td>\n        \n      </tr>\n<tr class="odd" data-id="4" rel="4">\n<td style="white-space:nowrap">priti</td>\n        \n        <td style="white-space:nowrap">staff1</td>\n        \n        <td style="white-space:nowrap">test</td>\n        \n        <td style="white-space:nowrap">Software</td>\n        \n        <td style="white-space:nowrap">high</td>\n        \n        <td style="white-space:nowrap">High</td>\n        \n        <td style="white-space:nowrap">dmsm</td>\n        \n        <td title="lkmdsfl">lkmdsfl</td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_edit ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/xepan/?subpage=xcustomercare-customerticketstatus&amp;edit=4&amp;36d6456c__erver_customerticketstatus_grid_edit=4'')"><span class="ui-button-text">Edit</span></button></td>\n        \n        <td style="white-space:nowrap"><button aria-disabled="false" role="button" type="button" class="button_delete ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" onclick="$(this).univ().ajaxec(''/xepan/?subpage=xcustomercare-customerticketstatus&amp;delete=4&amp;36d6456c__erver_customerticketstatus_grid_delete=4'')"><span class="ui-button-text">Delete</span></button></td>\n        \n      </tr>\n</tbody>\n</table>\n</div>\n</div>\n</div>\n\n', 'cursor: auto;', '2014-04-22 18:42:52', '2014-04-22 18:52:16', 'public', 5),
(11, 'xcustomercare-guestdashboard', '', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', NULL, NULL, '2014-04-22 18:48:23', '2014-04-22 18:48:23', 'public', 4),
(12, 'xcustomercare-faqs', '', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', NULL, NULL, '2014-04-22 18:48:53', '2014-04-22 18:49:12', 'public', 4),
(13, 'xcustomercare-customerdashboard', '', 1, 0, 'web', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', NULL, NULL, '2014-04-22 19:02:31', '2014-04-22 19:02:31', 'public', 5);

-- --------------------------------------------------------

--
-- Table structure for table `epan_page_snapshots`
--

CREATE TABLE IF NOT EXISTS `epan_page_snapshots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_page_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `body_attributes` text,
  `content` text,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `epan_page_snapshots`
--


-- --------------------------------------------------------

--
-- Table structure for table `epan_templates`
--

CREATE TABLE IF NOT EXISTS `epan_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` text,
  `is_current` tinyint(1) DEFAULT NULL,
  `css` text,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `epan_templates`
--

INSERT INTO `epan_templates` (`id`, `epan_id`, `name`, `content`, `is_current`, `css`) VALUES
(1, 1, 'default', '<div componenet_type="Main Contenet Area" style="" class="epan-component epan-sortable-componenet" id="MainContentArea">\r\n{{Content}}\r\n</div>\r\n\r\n\r\n', 1, NULL),
(3, 1, 'customerCareStaffTemplate', '\n			<nav id="babd9ca6-1255-4619-82eb-9d71c4f97534" component_namespace="menubarModule" component_type="MenuBar" style="" class="navbar navbar-default epan-component" role="navigation"> 	<!-- Brand and toggle get grouped for better mobile display --> 	<div class="navbar-header"> 		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse"> 			<span class="sr-only">Toggle navigation</span> 			<span class="icon-bar"></span> 			<span class="icon-bar"></span> 			<span class="icon-bar"></span> 		</button> 		 	</div> 	<!-- Collect the nav links, forms, and other content for toggling --> 	<div class="collapse navbar-collapse navbar-ex1-collapse"> 		<ul class="nav navbar-nav ui-sortable"> 			<li class="active"></li> 			 		<li><a href="?subpage=xcustomercare-staffprofile">Profile Update</a></li><li><a href="?subpage=xcustomercare-staffmessage">Message</a></li><li><a href="?subpage=xcustomercare-staffticket">Ticket Management</a></li><li><a href="?subpage=xcustomercare-staffproject">Project Management</a></li><li><a href="?page=logout">Logout</a></li></ul> 	</div><!-- /.navbar-collapse --> </nav><div componenet_type="Main Contenet Area" style="" class="epan-component epan-sortable-componenet" id="MainContentArea">\n<div id="e2e77564__econtenteditable" class="" style=""></div>\n<div id="d2718021__rversidecomponent" class="" style=""></div>\n<div id="5d9f7720__ateeditmode" class="" style=""></div>\n<div id="web_customercareapp_plugins_authenticationcheck" class="" style=""></div>\n<div style="" class="epan-component" component_type="MainContent" component_namespace="templateRegions" id="main-content-div" contenteditable="false"> 	{{Content}} </div>\n</div>\n		\n		', 0, ''),
(4, 1, 'customerCareGuestTemplate', '\n			\n			<nav id="08af03bf-f8fc-41b5-9883-50361375452d" component_namespace="menubarModule" component_type="MenuBar" style="opacity: 1; position: relative; left: 0px; top: 0px;" class="navbar navbar-default epan-component" role="navigation"> 	<!-- Brand and toggle get grouped for better mobile display --> 	<div class="navbar-header"> 		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse"> 			<span class="sr-only">Toggle navigation</span> 			<span class="icon-bar"></span> 			<span class="icon-bar"></span> 			<span class="icon-bar"></span> 		</button> 		 	</div> 	<!-- Collect the nav links, forms, and other content for toggling --> 	<div class="collapse navbar-collapse navbar-ex1-collapse"> 		<ul class="nav navbar-nav ui-sortable"><li><a href="?subpage=xcustomercare-faqs">FAQs</a></li><li><a href="?subpage=xcustomercare-customerlogin">Customer Login</a></li></ul> 	</div><!-- /.navbar-collapse --> </nav><div componenet_type="Main Contenet Area" style="" class="epan-component epan-sortable-componenet" id="MainContentArea">\n{{Content}}\n</div>\n\n\n\n		\n		', 0, ''),
(5, 1, 'customerCareCustomerTemplate', '\n			\n			\n			<nav id="607ee78e-5753-41f4-a57a-9e3bf08f69e1" component_namespace="menubarModule" component_type="MenuBar" style="" class="navbar navbar-default epan-component" role="navigation"> 	<!-- Brand and toggle get grouped for better mobile display --> 	<div class="navbar-header"> 		 		 	</div> 	<!-- Collect the nav links, forms, and other content for toggling --> 	<div class="collapse navbar-collapse navbar-ex1-collapse"> 		<ul class="nav navbar-nav ui-sortable"> 			 			 		<li><a href="?subpage=xcustomercare-customerdashboard">Dashboard</a></li><li><a href="?subpage=xcustomercare-customeropenticket">Open Ticket</a></li><li><a href="?subpage=xcustomercare-customerticketstatus">Status</a></li><li><a href="?page=logout">Logout</a></li></ul> 	</div><!-- /.navbar-collapse --> </nav><div componenet_type="Main Contenet Area" style="" class="epan-component epan-sortable-componenet" id="MainContentArea">\n{{Content}}\n</div>\n		\n		\n		', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `filestore_file`
--

CREATE TABLE IF NOT EXISTS `filestore_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filestore_type_id` int(11) NOT NULL DEFAULT '0',
  `filestore_volume_id` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `original_filename` varchar(255) DEFAULT NULL,
  `filesize` int(11) NOT NULL DEFAULT '0',
  `filenum` int(11) NOT NULL DEFAULT '0',
  `deleted` varchar(2) DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `filestore_file`
--

INSERT INTO `filestore_file` (`id`, `filestore_type_id`, `filestore_volume_id`, `filename`, `original_filename`, `filesize`, `filenum`, `deleted`) VALUES
(1, 4, 1, '0/20140410092132_1_thumb-koala.jpg', 'thumb_Koala.jpg', 6165, 0, '0'),
(2, 4, 1, '0/20140410092132__koala.jpg', 'Koala.jpg', 780831, 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `filestore_image`
--

CREATE TABLE IF NOT EXISTS `filestore_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `original_file_id` int(11) NOT NULL DEFAULT '0',
  `thumb_file_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `filestore_image`
--

INSERT INTO `filestore_image` (`id`, `name`, `original_file_id`, `thumb_file_id`) VALUES
(1, NULL, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `filestore_type`
--

CREATE TABLE IF NOT EXISTS `filestore_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(64) NOT NULL DEFAULT '',
  `extension` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `filestore_type`
--

INSERT INTO `filestore_type` (`id`, `name`, `mime_type`, `extension`) VALUES
(1, 'png', 'image/png', 'png'),
(2, 'jpeg', 'image/jpeg', 'jpeg'),
(3, 'gif', 'image/gif', 'gif'),
(4, 'jpg', 'image/jpg', 'jpg');

-- --------------------------------------------------------

--
-- Table structure for table `filestore_volume`
--

CREATE TABLE IF NOT EXISTS `filestore_volume` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `dirname` varchar(255) NOT NULL DEFAULT '',
  `total_space` bigint(20) NOT NULL DEFAULT '0',
  `used_space` bigint(20) NOT NULL DEFAULT '0',
  `stored_files_cnt` int(11) NOT NULL DEFAULT '0',
  `enabled` enum('Y','N') DEFAULT 'Y',
  `last_filenum` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `filestore_volume`
--

INSERT INTO `filestore_volume` (`id`, `name`, `dirname`, `total_space`, `used_space`, `stored_files_cnt`, `enabled`, `last_filenum`) VALUES
(1, 'upload', 'upload', 1000000000, 0, 5, 'Y', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `message` text,
  `created_at` datetime DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `sender_signature` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `access_level` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_staff_branche1` (`branch_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `staff`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `last_login_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `epan_id`, `name`, `username`, `password`, `created_at`, `type`, `email`, `is_active`, `activation_code`, `last_login_date`) VALUES
(1, 1, 'admin', 'admin', 'admin', '2014-02-15', 'SuperUser', NULL, 1, NULL, NULL),
(2, 2, 'kriti', 'kriti', 'admin2', '2014-03-25', 'SuperUser', NULL, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `visitorcounterapp_config`
--

CREATE TABLE IF NOT EXISTS `visitorcounterapp_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `show_total` tinyint(1) DEFAULT NULL,
  `show_yearly` tinyint(1) DEFAULT NULL,
  `show_monthly` tinyint(1) DEFAULT NULL,
  `show_daily` tinyint(1) DEFAULT NULL,
  `theme` varchar(255) DEFAULT NULL,
  `font_size` varchar(255) DEFAULT NULL,
  `start_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `visitorcounterapp_config`
--

INSERT INTO `visitorcounterapp_config` (`id`, `epan_id`, `show_total`, `show_yearly`, `show_monthly`, `show_daily`, `theme`, `font_size`, `start_number`) VALUES
(2, 1, 1, 0, 0, 0, 'car', '12px', '2345');

-- --------------------------------------------------------

--
-- Table structure for table `visitorcounterapp_visits`
--

CREATE TABLE IF NOT EXISTS `visitorcounterapp_visits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` datetime DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `visitorcounterapp_visits`
--

