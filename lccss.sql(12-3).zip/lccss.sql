-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 13, 2014 at 09:31 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lccss`
--

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE IF NOT EXISTS `alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `sender_signature` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `alerts`
--


-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `points` varchar(255) DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(255) DEFAULT NULL,
  `address` text,
  `created_at` date DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `name`, `points`, `owner_name`, `mobile_number`, `address`, `created_at`, `email_id`) VALUES
(1, 'Default', '500000', 'Xavoc Technocrats', '+91 8875191258', '18/436 Gayatri Marg, Kanji Ka Hata, Dhabai Ji Ka Wada, udaipur', '2011-12-12', 'info@xavoc.com');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_company`
--

CREATE TABLE IF NOT EXISTS `customercareapp_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `epan_id` int(11) DEFAULT NULL,
  `company_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `customercareapp_company`
--

INSERT INTO `customercareapp_company` (`id`, `name`, `epan_id`, `company_address`) VALUES
(1, 'xavoc222', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_config`
--

CREATE TABLE IF NOT EXISTS `customercareapp_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerCareApp_company_id` int(11) DEFAULT NULL,
  `updated` varchar(255) DEFAULT NULL,
  `customerCareApp_ticket_priority_id` int(11) DEFAULT NULL,
  `helpDeskName` varchar(255) DEFAULT NULL,
  `helpDeskUrl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customerCareApp_company_id` (`customerCareApp_company_id`),
  KEY `fk_customerCareApp_ticket_priority_id` (`customerCareApp_ticket_priority_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customercareapp_config`
--

INSERT INTO `customercareapp_config` (`id`, `customerCareApp_company_id`, `updated`, `customerCareApp_ticket_priority_id`, `helpDeskName`, `helpDeskUrl`) VALUES
(1, NULL, '', NULL, 'shahi', ''),
(2, NULL, '', NULL, 'shahi1', '');

-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_department`
--

CREATE TABLE IF NOT EXISTS `customercareapp_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_company_id` (`company_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customercareapp_department`
--


-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_emailtemplate`
--

CREATE TABLE IF NOT EXISTS `customercareapp_emailtemplate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerCareApp_company_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customerCareApp_company_id` (`customerCareApp_company_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customercareapp_emailtemplate`
--


-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_issue`
--

CREATE TABLE IF NOT EXISTS `customercareapp_issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerCareApp_company_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customerCareApp_company_id` (`customerCareApp_company_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customercareapp_issue`
--


-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_staff`
--

CREATE TABLE IF NOT EXISTS `customercareapp_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_team_id` (`team_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customercareapp_staff`
--


-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_team`
--

CREATE TABLE IF NOT EXISTS `customercareapp_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_department_id` (`department_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customercareapp_team`
--


-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_ticket`
--

CREATE TABLE IF NOT EXISTS `customercareapp_ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ticket_priority_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_company_id` (`company_id`),
  KEY `fk_department_id` (`department_id`),
  KEY `fk_user_id` (`user_id`),
  KEY `fk_ticket_priority_id` (`ticket_priority_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customercareapp_ticket`
--


-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_ticket_priority`
--

CREATE TABLE IF NOT EXISTS `customercareapp_ticket_priority` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customercareapp_ticket_priority`
--


-- --------------------------------------------------------

--
-- Table structure for table `customercareapp_user`
--

CREATE TABLE IF NOT EXISTS `customercareapp_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerCareApp_company_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customerCareApp_company_id` (`customerCareApp_company_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customercareapp_user`
--


-- --------------------------------------------------------

--
-- Table structure for table `epan`
--

CREATE TABLE IF NOT EXISTS `epan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `fund_alloted` varchar(255) DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `contact_person_name` varchar(255) DEFAULT NULL,
  `mobile_no` varchar(255) DEFAULT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `website` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT NULL,
  `last_email_sent` datetime DEFAULT NULL,
  `allowed_aliases` int(11) DEFAULT NULL,
  `parked_domain` varchar(255) DEFAULT NULL,
  `email_host` varchar(255) DEFAULT NULL,
  `email_port` varchar(255) DEFAULT NULL,
  `email_username` varchar(255) DEFAULT NULL,
  `email_password` varchar(255) DEFAULT NULL,
  `email_reply_to` varchar(255) DEFAULT NULL,
  `email_reply_to_name` varchar(255) DEFAULT NULL,
  `email_from` varchar(255) DEFAULT NULL,
  `email_from_name` varchar(255) DEFAULT NULL,
  `is_frontent_regiatrstion_allowed` tinyint(1) DEFAULT NULL,
  `user_activation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_staff1` (`staff_id`),
  KEY `fk_epan_epan_categories1` (`category_id`),
  FULLTEXT KEY `tags_description_full_text` (`keywords`,`description`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `epan`
--

INSERT INTO `epan` (`id`, `name`, `staff_id`, `branch_id`, `password`, `fund_alloted`, `created_at`, `category_id`, `company_name`, `contact_person_name`, `mobile_no`, `address`, `city`, `state`, `country`, `email_id`, `keywords`, `description`, `website`, `is_active`, `is_approved`, `last_email_sent`, `allowed_aliases`, `parked_domain`, `email_host`, `email_port`, `email_username`, `email_password`, `email_reply_to`, `email_reply_to_name`, `email_from`, `email_from_name`, `is_frontent_regiatrstion_allowed`, `user_activation`) VALUES
(1, 'web', 1, 1, 'admin', '5000000', '2014-01-26', 1, 'Xavoc Technocrats Pvt. Ltd.', 'Xavoc Admin', '+91 8875191258', '18/436, Gayatri marg, Kanji Ka hata, Udaipur, Rajasthan , India', 'Udaipur', 'Rajasthan', 'India', 'info@xavoc.com', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', 'World''s best and easiest cms :)', 'http://www.xavoc.com', 1, 1, NULL, 1, NULL, '', '', '', '', '', '', '', '', 1, 'self_activated');

-- --------------------------------------------------------

--
-- Table structure for table `epan_aliases`
--

CREATE TABLE IF NOT EXISTS `epan_aliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `epan_aliases`
--


-- --------------------------------------------------------

--
-- Table structure for table `epan_categories`
--

CREATE TABLE IF NOT EXISTS `epan_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `parent_category_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cat_id` (`id`),
  KEY `cat_parent` (`parent_category_id`),
  KEY `func_getPathWay` (`id`,`parent_category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `epan_categories`
--

INSERT INTO `epan_categories` (`id`, `name`, `description`, `parent_category_id`, `ordering`) VALUES
(1, 'Default', 'Default', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `epan_components_marketplace`
--

CREATE TABLE IF NOT EXISTS `epan_components_marketplace` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `is_final` tinyint(1) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `allowed_children` varchar(255) DEFAULT NULL,
  `specific_to` varchar(255) DEFAULT NULL,
  `namespace` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `is_system` tinyint(1) DEFAULT NULL,
  `plugin_hooked` text,
  `description` text,
  `default_enabled` tinyint(1) DEFAULT NULL,
  `has_toolbar_tools` tinyint(1) DEFAULT NULL,
  `has_owner_modules` tinyint(1) DEFAULT NULL,
  `has_plugins` tinyint(1) DEFAULT NULL,
  `has_live_edit_app_page` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `epan_components_marketplace`
--

INSERT INTO `epan_components_marketplace` (`id`, `name`, `is_final`, `rate`, `allowed_children`, `specific_to`, `namespace`, `type`, `is_system`, `plugin_hooked`, `description`, `default_enabled`, `has_toolbar_tools`, `has_owner_modules`, `has_plugins`, `has_live_edit_app_page`) VALUES
(1, 'Image', 1, '50', NULL, NULL, 'imageElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(2, 'RowColumn', 0, '0', '3', '', 'rowColumnElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(4, 'SlideShow', 0, '0', '5', '', 'slideshowModule', 'module', 0, NULL, NULL, NULL, 1, NULL, 0, NULL),
(6, 'Text', 0, '0', NULL, NULL, 'textElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(7, 'Title', 1, '0', NULL, NULL, 'titleElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(8, 'EnquiryForm', 1, '0', '', NULL, 'enquiryformModule', 'module', 0, NULL, NULL, NULL, 1, NULL, 0, NULL),
(10, 'MenuBar', 0, '0', '11', '', 'menubarModule', 'module', 0, NULL, NULL, NULL, 1, NULL, 0, NULL),
(13, 'SystemContentManipulations', 1, '0', NULL, NULL, 'systemcontentmanipulationPlugins', 'plugins', 1, 'output-fetched', NULL, 1, NULL, NULL, 1, NULL),
(12, 'Container', 0, '0', '', '', 'containerElement', 'element', 1, NULL, NULL, NULL, 1, NULL, 0, NULL),
(16, 'SocialShare', NULL, NULL, NULL, NULL, 'socialshareModule', 'module', 0, NULL, NULL, NULL, 1, NULL, 0, NULL),
(20, 'Backup And Restore App', NULL, NULL, NULL, NULL, 'backupandrestoreApp', 'application', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'Simple Image Gallary App', NULL, NULL, NULL, NULL, 'simpleImageGallaryApp', 'application', 0, NULL, 'bla bla bla', 0, 1, 0, 0, 0),
(22, 'Visitor Counter', NULL, NULL, NULL, NULL, 'visitorCounterApp', 'application', 0, 'epan-hit', 'sdfsd', 0, 1, 0, 0, 0),
(26, 'User Login', NULL, NULL, NULL, NULL, 'userLoginElement', 'element', 1, NULL, NULL, 0, 1, NULL, NULL, NULL),
(28, 'customerCareApp', 0, '0', NULL, NULL, 'customerCareApp', 'adpplication', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `epan_installed_components`
--

CREATE TABLE IF NOT EXISTS `epan_installed_components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `component_id` int(11) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `params` varchar(255) DEFAULT NULL,
  `installed_on` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `epan_installed_components`
--

INSERT INTO `epan_installed_components` (`id`, `epan_id`, `component_id`, `enabled`, `params`, `installed_on`) VALUES
(1, 1, 13, 1, NULL, '2014-01-26'),
(2, 1, 8, 1, NULL, '2014-01-27'),
(5, 1, 27, 1, NULL, '2014-02-06'),
(6, 1, 10, 1, NULL, '2014-02-08'),
(9, 1, 4, 1, NULL, '2014-02-09'),
(11, 1, 21, 1, NULL, '2014-02-09'),
(12, 1, 22, 1, NULL, '2014-02-09'),
(13, 1, 28, 1, NULL, '2014-02-17');

-- --------------------------------------------------------

--
-- Table structure for table `epan_page`
--

CREATE TABLE IF NOT EXISTS `epan_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `menu_caption` varchar(255) DEFAULT NULL,
  `epan_id` int(11) DEFAULT NULL,
  `is_template` tinyint(1) DEFAULT NULL,
  `title` text,
  `description` text,
  `keywords` text,
  `content` text,
  `body_attributes` text,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `access_level` varchar(255) DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_page_epan1` (`epan_id`),
  KEY `fk_template_id` (`template_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `epan_page`
--

INSERT INTO `epan_page` (`id`, `name`, `menu_caption`, `epan_id`, `is_template`, `title`, `description`, `keywords`, `content`, `body_attributes`, `created_on`, `updated_on`, `access_level`, `template_id`) VALUES
(1, 'home', 'Home', 1, 0, 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', 'World''s best and easiest cms :)', 'xEpan CMS, an innovative approach towards Drag And Drop CMS.', NULL, 'cursor: auto;', NULL, '2014-02-17 07:55:53', 'public', 1);

-- --------------------------------------------------------

--
-- Table structure for table `epan_page_snapshots`
--

CREATE TABLE IF NOT EXISTS `epan_page_snapshots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_page_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` text,
  `description` text,
  `body_attributes` text,
  `content` text,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `epan_page_snapshots`
--


-- --------------------------------------------------------

--
-- Table structure for table `epan_templates`
--

CREATE TABLE IF NOT EXISTS `epan_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` text,
  `is_current` tinyint(1) DEFAULT NULL,
  `css` text,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `epan_templates`
--

INSERT INTO `epan_templates` (`id`, `epan_id`, `name`, `content`, `is_current`, `css`) VALUES
(1, 1, 'default', '{{Content}}', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `message` text,
  `created_at` datetime DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `sender_signature` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `access_level` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_staff_branche1` (`branch_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `staff`
--


-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE IF NOT EXISTS `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `members` varchar(255) DEFAULT NULL,
  `team_lead` varchar(255) DEFAULT NULL,
  `created` varchar(255) DEFAULT NULL,
  `last_updated` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `Dropdown` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `teams`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `last_login_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `epan_id`, `name`, `username`, `password`, `created_at`, `type`, `email`, `is_active`, `activation_code`, `last_login_date`) VALUES
(1, 1, 'Admin', 'admin', 'admin', '2014-02-17', 'SuperUser', NULL, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `visitorcounterapp_config`
--

CREATE TABLE IF NOT EXISTS `visitorcounterapp_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `show_total` tinyint(1) DEFAULT NULL,
  `show_yearly` tinyint(1) DEFAULT NULL,
  `show_monthly` tinyint(1) DEFAULT NULL,
  `show_daily` tinyint(1) DEFAULT NULL,
  `theme` varchar(255) DEFAULT NULL,
  `font_size` varchar(255) DEFAULT NULL,
  `start_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `visitorcounterapp_config`
--

INSERT INTO `visitorcounterapp_config` (`id`, `epan_id`, `show_total`, `show_yearly`, `show_monthly`, `show_daily`, `theme`, `font_size`, `start_number`) VALUES
(2, 1, 1, 0, 0, 0, 'car', '12px', '2345');

-- --------------------------------------------------------

--
-- Table structure for table `visitorcounterapp_visits`
--

CREATE TABLE IF NOT EXISTS `visitorcounterapp_visits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epan_id` int(11) DEFAULT NULL,
  `name` datetime DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_epan_id` (`epan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `visitorcounterapp_visits`
--

